## Směrnice NIS
### Subjekty:
- Poskytovatelé služeb digitální infrastruktury (např. energetické firmy, poskytovatelé digitálních služeb, banky atd.)
- Poskytovatelé digitálních služeb (např. tržiště online, cloudové služby atd.)

### Sankce:
- Členské státy musí zavést účinné, proporcionální a odstrašující sankce za porušení povinností stanovených touto směrnicí.
- Výše sankcí se může lišit v jednotlivých členských státech.

## Směrnice NIS2
### Rozšíření:
- Rozšiřuje rozsah směrnice na další subjekty, jako jsou digitální platformy a online tržiště.

### Sankce:
- Obsahuje změny ve výši sankcí a dalších opatřeních k zajištění souladu s novými požadavky směrnice.

## Srovnání:
|                       | Směrnice NIS                               | Směrnice NIS2                                      |
|-----------------------|--------------------------------------------|-----------------------------------------------------|
| **Subjekty**          | - Poskytovatelé služeb digitální infrastruktury <br> - Poskytovatelé digitálních služeb | - Poskytovatelé služeb digitální infrastruktury <br> - Poskytovatelé digitálních služeb <br> - Digitální platformy <br> - Online tržiště |
| **Sankce**            | - Členské státy musí zavést účinné, proporcionální a odstrašující sankce. <br> - Výše sankcí se může lišit v jednotlivých členských státech. | - Obsahuje změny ve výši sankcí a dalších opatřeních. |

